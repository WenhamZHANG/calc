//
//
//
//
//  Created by wenhao zhang 12869970 on 10/04/2020.
//
//  Subject IOS application development
//
//  Assignment 1 calculatore
//
//  Comend line tools
//
//



import Foundation
//  digit regular expression,  * means at least 0, + means at least 1
let regOfDigit = "[+-]*[0-9]+"




//  operator regular expression
let regOfOperator = "[+-/x%]"



//  predicate filtering
let preOfDigit = NSPredicate(format: "SELF MATCHES %@", regOfDigit)
let preOfOperator = NSPredicate(format: "SELF MATCHES %@", regOfOperator)

//  parameter
let argus = Swift.CommandLine.arguments


// expression source

var expressArr = [String]()



/*

 1. operators and digit, the digit  must one more than operators,
 2. must ineger
 
 
 */



func checkArgus()->Bool {
    
    
    var countOfOperator = 0
    var countOfDigit = 0
    
    
    for index in 1..<argus.count {
        
        
        if preOfDigit.evaluate(with: argus[index]) {
            
            
            //  judge is ndigit or not
            countOfDigit = countOfDigit + 1;
            
        } else if preOfOperator.evaluate(with: argus[index]) {
            
            
            
            // judge is operators or not
            countOfOperator = countOfOperator + 1;
            
        } else {
            
            print("Parameter input ERROR\(argus[index])")
            return false;
        }
        
        expressArr.append(argus[index]);
    }
    
    
    //a + b x c /d % e, count number> 0 and count operators at least 1
    return expressArr.count > 0 && countOfDigit == countOfOperator + 1;
}







/*
 
 1. the order of muti-level operation
 
 
 2.divide 0, error
 
 */



func cal() {
    
    
    if expressArr.count == 1 {
        print(expressArr.first!)
        return;
    }
    
    
    
    print(expressArr.joined(separator: " "))
    
    
    
    // start computing location
    
    var start = 0
    for index in 0..<expressArr.count {
        
        
        
        //  prior  calcuate  x / %
        if preOfOperator.evaluate(with: expressArr[index]) {
            switch expressArr[index] {
            case "x","/","%":
                start = index - 1
            default:
                break
                
                
            }
        }
        
        
        if start > 0 {
            break;
        }
        
    }
    
    
    
    
    // calcuate
    let numLeft = Int(expressArr[start])
    let numRight = Int(expressArr[start+2])
    
    
    
    
    //  results
    var value = 0;
    
    
    switch expressArr[start+1] {
    case "+":
        value = numLeft! + numRight!
    case "-":
        value = numLeft! - numRight!
    case "x":
        value = numLeft! * numRight!
    case "/":
        
        
        
        
        // divide 0, error
        
        
        if numRight! == 0 {
            print("Divisor 0 Error")
            return;
        }
        value = numLeft! / numRight!
    case "%":
        
        
        
        if numRight! == 0 {
            print("Divisor 0 Error")
            return;
            
        }
        value = numLeft! % numRight!
        
        
    default:
        break;
    }
    
    
    
    // delete left
    expressArr.remove(at: start)
    
    
    
    // delete operator
    expressArr.remove(at: start)
    
    
    // delete right
    expressArr.remove(at: start)
    
    
    
    // insert start
    expressArr.insert(String(value), at: start)
    cal()
    
    
    
}





//   entry
if checkArgus() {
    cal();
}
